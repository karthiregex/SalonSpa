﻿using SaloneSpa.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SaloneSpa.BusinessLayer.Services.Repository
{
    public interface ISalonSpaRepository
    {
        //List of method to perform all related operation
        Task<IEnumerable<ServicesPlan>> GetAllServicesPlan();
        Task<ServicesPlan> GetServicesPlanById(string PlanId);
        Task<ServicesPlan> ServicesPlanByTitle(string title);
        Task<bool> SalonAppointment(Appointment appointment);
        Task<bool> NewApplicationUser(ApplicationUser user);
        Task<IEnumerable<SalonServices>> SalonServicesList();
        Task<SalonServices> SalonServicesById(string salonServicesId);
    }
}
