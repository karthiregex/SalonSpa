﻿using SaloneSpa.Entities;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SaloneSpa.BusinessLayer.Services.Repository
{
    public interface IAdminSalonSpaRepository
    {
        Task<IEnumerable<Appointment>> UserAppointment();
        Task<Appointment> UpdateAppointment(string AppointmentId);
        Task<Appointment> GetAppointmentById(string appointmentId);
        Task<bool> AddSalonServices(SalonServices salonServices);
        Task<SalonServices> UpdateSalonServices(string SalonServicesId);
        Task<bool> DeleteSalonServices(string SalonServicesId);
        Task<bool> AddServicesPlan(ServicesPlan servicesPlan);
        Task<ServicesPlan> UpdateServicesPlan(string PlanId);
        Task<bool> DeleteServicesPlan(string PlanId);
    }
}
