﻿using SaloneSpa.DataLayer;
using SaloneSpa.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SaloneSpa.BusinessLayer.Services.Repository
{
    public class SalonSpaRepository : ISalonSpaRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in SalonSpaRepository constructor
        /// </summary>
        private readonly SalonSpaDbContext _salonContext;
        public SalonSpaRepository(SalonSpaDbContext salonDbContext)
        {
            _salonContext = salonDbContext;
        }
        /// <summary>
        /// Get all services plan for user.
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ServicesPlan>> GetAllServicesPlan()
        {
            try
            {
                var list = await _salonContext.servicePlans.ToListAsync();
                return list;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Get Services plan by Plan Id
        /// </summary>
        /// <param name="PlanId"></param>
        /// <returns></returns>
        public async Task<ServicesPlan> GetServicesPlanById(string PlanId)
        {
            try
            {
                var result = await _salonContext.servicePlans
                  .FirstOrDefaultAsync(h => h.PlanId.Equals(PlanId));
                return result;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        /// <summary>
        /// Register a new user into the Application
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<bool> NewApplicationUser(ApplicationUser user)
        {
            try
            {
                await _salonContext.applicationUsers.AddAsync(user);
                await _salonContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// Book Salon Appointment.
        /// </summary>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<bool> SalonAppointment(Appointment appointment)
        {
            try
            {
                await _salonContext.appointments.AddAsync(appointment);
                await _salonContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// Get salon services by Id.
        /// </summary>
        /// <param name="salonServicesId"></param>
        /// <returns></returns>
        public async Task<SalonServices> SalonServicesById(string salonServicesId)
        {
            try
            {
                var result = await _salonContext.saloneServices
                  .FirstOrDefaultAsync(h => h.SalonServicesId.Equals(salonServicesId));
                return result;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Get Salon services List
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<SalonServices>> SalonServicesList()
        {
            try
            {
                var list = await _salonContext.saloneServices.ToListAsync();
                return list;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Get salon services plan by Title and Name
        /// </summary>
        /// <param name="title"></param>
        /// <returns></returns>
        public async Task<ServicesPlan> ServicesPlanByTitle(string title)
        {
            try
            {
                var result = await _salonContext.servicePlans
                    .FirstOrDefaultAsync(h => h.Title.Equals(title));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
