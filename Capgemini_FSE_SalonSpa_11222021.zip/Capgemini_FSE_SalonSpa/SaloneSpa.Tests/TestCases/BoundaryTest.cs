﻿using SaloneSpa.BusinessLayer;
using SaloneSpa.BusinessLayer.Interfaces;
using SaloneSpa.BusinessLayer.Services;
using SaloneSpa.BusinessLayer.Services.Repository;
using SaloneSpa.Entities;
using Moq;
using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Xunit;
using Microsoft.AspNetCore.Identity;
using Xunit.Abstractions;
using System.Collections.Generic;

namespace SaloneSpa.Tests.TestCases
{
    public class BoundaryTest
    {
        /// <summary>
        /// Creating Referance of all Service Interfaces and Mocking All Repository
        /// </summary>
        private readonly IAdminSalonSpaServices _adminServices;
        private readonly ISalonSpaServices _salonSpaServices;
        public readonly Mock<IAdminSalonSpaRepository> adminService = new Mock<IAdminSalonSpaRepository>();
        public readonly Mock<ISalonSpaRepository> salonServices = new Mock<ISalonSpaRepository>();
        private Appointment _appointment;
        private ApplicationUser _user;
        private SalonServices _salonServices;
        private ServicesPlan _servicesPlan;
        private IEnumerable<ServicesPlan> _servicesPlanList;
        private IEnumerable<Appointment> _appointmentList;
        private IEnumerable<SalonServices> _salonServiceList;

        readonly private ITestOutputHelper _output;
        readonly private static string type = "Boundary";
        private IdentityResult identiyResult;
        public BoundaryTest(ITestOutputHelper output)
        {
            _adminServices = new AdminSalonSpaServices(adminService.Object);
            _salonSpaServices = new SalonSpaServices(salonServices.Object);
            _output = output;
            _servicesPlanList = new List<ServicesPlan>();
            _appointmentList = new List<Appointment>();
            _salonServiceList = new List<SalonServices>();
            _appointment = new Appointment
            {
                AppointmentId = "5ff45caf62416905a5e6a1b8",
                Name = "Kumar Kaushal",
                Mobile = 9632545785,
                Email = "services@iiht.co.in",
                ServicesPlan = "1"
            };
            _user = new ApplicationUser
            {
                UserId = "5ff462f59c249e27020bffba",
                Name = "karthikeyan",
                Email = "umakumarsingh@gmail.com",
                MobileNumber = 9865253568,
                PinCode = 820003,
                HouseNo_Building_Name = "9/11",
                Road_area = "Road_area",
                City = "Gaya",
                State = "Bihar"
            };
            _salonServices = new SalonServices
            {
                SalonServicesId = "5ff467219c249e27020bffbb",
                ServicesId = 1,
                Name = "SKIN",
                Url = "~/SalonSpa/",
                OpenInNewWindow = false,
                Description = null
            };
            _servicesPlan = new ServicesPlan
            {
                PlanId = "5ff45f309c249e27020bffb9",
                PlanName = "Skin Care - Treatments",
                Title = "Spot Lights - Organic Eye- Lip Treatment",
                Description = "Reduce Dryness From Your Eyes And Lips With A Treatment Designed To Tr...",
                Price = 1250,
                ServiceId = 1
            };
        }

        /// <summary>
        /// Test for Validate SalonServicesId is used to test Salon Services is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_SalonServicesId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                adminService.Setup(repo => repo.AddSalonServices(_salonServices)).ReturnsAsync(res);
                var result = await _adminServices.AddSalonServices(_salonServices);

                if (result.SalonServicesId.Length.ToString() == _salonServices.SalonServicesId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate ServicesPlan Id is used to test Services Plan is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Service_PlanId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                adminService.Setup(repo => repo.AddServicesPlan(_servicesPlan)).ReturnsAsync(res);
                var result = await _adminServices.AddServicesPlan(_servicesPlan);

                if (result.PlanId.Length.ToString() == _salonServices.SalonServicesId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate Delete SalonServices Plan is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_DeleteSalonServices()
        {
            //Arrange
            bool res = false;
            string SalonServicesId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                adminService.Setup(repo => repo.DeleteSalonServices(SalonServicesId)).ReturnsAsync(res);
                var result = await _adminServices.DeleteSalonServices(SalonServicesId);

                if (result)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate Delete ServicesPlan is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_DeleteServicesPlan()
        {
            //Arrange
            bool res = false;
            string PlanId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                adminService.Setup(repo => repo.DeleteServicesPlan(PlanId)).ReturnsAsync(res);
                var result = await _adminServices.DeleteServicesPlan(PlanId);

                if (result)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate Get the Appointment By Id is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_GetAppointmentById()
        {
            //Arrange
            bool res = false;
            string appointmentId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                adminService.Setup(repo => repo.GetAppointmentById(appointmentId)).ReturnsAsync(_appointment);
                var result = await _adminServices.GetAppointmentById(appointmentId);

                if (result.AppointmentId.Length.ToString() == _appointment.AppointmentId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate Update the Appointment By Id is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_UpdateAppointment()
        {
            //Arrange
            bool res = false;
            string appointmentId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                adminService.Setup(repo => repo.UpdateAppointment(appointmentId)).ReturnsAsync(_appointment);
                var result = await _adminServices.UpdateAppointment(appointmentId);

                if (result.AppointmentId.Length.ToString() == _appointment.AppointmentId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate Update the SalonServices By Id is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_UpdateSalonServices()
        {
            //Arrange
            bool res = false;
            string SalonServicesId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                adminService.Setup(repo => repo.UpdateSalonServices(SalonServicesId)).ReturnsAsync(_salonServices);
                var result = await _adminServices.UpdateSalonServices(SalonServicesId);

                if (result.SalonServicesId.Length.ToString() == _salonServices.SalonServicesId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate Update the SalonServices By Id is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_UpdateServicesPlan()
        {
            //Arrange
            bool res = false;
            string PlanId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                adminService.Setup(repo => repo.UpdateServicesPlan(PlanId)).ReturnsAsync(_servicesPlan);
                var result = await _adminServices.UpdateServicesPlan(PlanId);

                if (result.PlanId.Length.ToString() == _servicesPlan.PlanId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate UserId is used to test UserId is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_UserId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                salonServices.Setup(repo => repo.NewApplicationUser(_user)).ReturnsAsync(res);
                var result = await _salonSpaServices.NewApplicationUser(_user);

                if (result.UserId.Length.ToString() == _user.UserId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate AppointmentId is used to test Appointment is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_AppointmentId()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                salonServices.Setup(repo => repo.SalonAppointment(_appointment)).ReturnsAsync(res);
                var result = await _salonSpaServices.SalonAppointment(_appointment);

                if (result.AppointmentId.Length.ToString() == _appointment.AppointmentId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for validate AllServicesPlan is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_GetAllServicesPlan()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                salonServices.Setup(repo => repo.GetAllServicesPlan()).ReturnsAsync(_servicesPlanList);
                var result = await _salonSpaServices.GetAllServicesPlan();

                if (result != null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate PlanId is used to test GetServicesPlanById is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_GetServicesPlanById()
        {
            //Arrange
            bool res = false;
            string PlanId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                salonServices.Setup(repo => repo.GetServicesPlanById(PlanId)).ReturnsAsync(_servicesPlan);
                var result = await _salonSpaServices.GetServicesPlanById(PlanId);

                if (result.PlanId.Length.ToString() == _servicesPlan.PlanId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate salonServicesId is used to test SalonServicesById is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_SalonServicesById()
        {
            //Arrange
            bool res = false;
            string salonServicesId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                salonServices.Setup(repo => repo.SalonServicesById(salonServicesId)).ReturnsAsync(_salonServices);
                var result = await _salonSpaServices.SalonServicesById(salonServicesId);

                if (result.SalonServicesId.Length.ToString() == _salonServices.SalonServicesId.Length.ToString())
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate SalonServicesList is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_SalonServicesList()
        {
            //Arrange
            bool res = false;
            string salonServicesId = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                salonServices.Setup(repo => repo.SalonServicesList()).ReturnsAsync(_salonServiceList);
                var result = await _salonSpaServices.SalonServicesList();

                if (result != null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// Test for Validate ServicesPlanByTitle is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_ServicesPlanByTitle()
        {
            //Arrange
            bool res = false;
            string title = string.Empty;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                salonServices.Setup(repo => repo.ServicesPlanByTitle(title)).ReturnsAsync(_servicesPlan);
                var result = await _salonSpaServices.ServicesPlanByTitle(title);

                if (result != null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }
            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
    }
}