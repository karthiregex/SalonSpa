﻿using SaloneSpa.BusinessLayer;
using SaloneSpa.BusinessLayer.Interfaces;
using SaloneSpa.BusinessLayer.Services;
using SaloneSpa.BusinessLayer.Services.Repository;
using SaloneSpa.Entities;
using Microsoft.AspNetCore.Identity;
using Moq;
using System;
using System.IO;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;
using System.Collections.Generic;

namespace SaloneSpa.Tests.TestCases
{
    public class ExceptionalTest
    {
        /// <summary>
        /// Creating Referance of all Service Interfaces and Mocking All Repository
        /// </summary>
        private readonly IAdminSalonSpaServices _adminServices;
        private readonly ISalonSpaServices _salonSpaServices;
        public readonly Mock<IAdminSalonSpaRepository> adminService = new Mock<IAdminSalonSpaRepository>();
        public readonly Mock<ISalonSpaRepository> salonServices = new Mock<ISalonSpaRepository>();
        private Appointment _appointment;
        private ApplicationUser _user;
        private SalonServices _salonServices;
        private IEnumerable<SalonServices> _salonServiceList;
        private IEnumerable<Appointment> _appointmentList;
        private ServicesPlan _servicesPlan;
        private readonly ITestOutputHelper _output;
        private static readonly string type = "Exceptional";
        public ExceptionalTest(ITestOutputHelper output)
        {
            _adminServices = new AdminSalonSpaServices(adminService.Object);
            _salonSpaServices = new SalonSpaServices(salonServices.Object);
            _output = output;
            _appointment = new Appointment
            {
                AppointmentId = "5ff45caf62416905a5e6a1b8",
                Name = "Kumar Kaushal",
                Mobile = 9632545785,
                Email = "services@iiht.co.in",
                ServicesPlan = "1"
            };
            _user = new ApplicationUser
            {
                UserId = "5ff462f59c249e27020bffba",
                Name = "Uma Kumar",
                Email = "umakumarsingh@gmail.com",
                MobileNumber = 9865253568,
                PinCode = 820003,
                HouseNo_Building_Name = "9/11",
                Road_area = "Road_area",
                City = "Gaya",
                State = "Bihar"
            };
            _salonServices = new SalonServices
            {
                SalonServicesId = "5ff467219c249e27020bffbb",
                ServicesId = 1,
                Name = "SKIN",
                Url = "~/SalonSpa/",
                OpenInNewWindow = false,
                Description = null
            };
            _servicesPlan = new ServicesPlan
            {
                PlanId = "5ff45f309c249e27020bffb9",
                PlanName = "Skin Care - Treatments",
                Title = "Spot Lights - Organic Eye- Lip Treatment",
                Description = "Reduce Dryness From Your Eyes And Lips With A Treatment Designed To Tr...",
                Price = 1250,
                ServiceId = 1
            };
        }

        /// <summary>
        /// This Method is used for test Add Valid ServicesPlanId is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_ServicesPlanId()
        {
            //Arrange
            bool res = false;
            string PlanId = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                salonServices.Setup(repo => repo.GetServicesPlanById(PlanId)).ReturnsAsync(_servicesPlan);
                var result = await _salonSpaServices.GetServicesPlanById(PlanId);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }


        /// <summary>
        /// This Method is used for test Add Valid Appointment is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_Appointment()
        {
            //Arrange
            bool res = false;
            _appointment = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                salonServices.Setup(repo => repo.SalonAppointment(_appointment)).ReturnsAsync(res);
                var result = await _salonSpaServices.SalonAppointment(_appointment);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test SalonServicesById is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_SalonServicesById()
        {
            //Arrange
            bool res = false;
            string salonServicesId = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                salonServices.Setup(repo => repo.SalonServicesById(salonServicesId)).ReturnsAsync(_salonServices);
                var result = await _salonSpaServices.SalonServicesById(salonServicesId);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test ServicesPlanByTitle is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_ServicesPlanByTitle()
        {
            //Arrange
            bool res = false;
            string title = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                salonServices.Setup(repo => repo.ServicesPlanByTitle(title)).ReturnsAsync(_servicesPlan);
                var result = await _salonSpaServices.ServicesPlanByTitle(title);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test SalonServicesList is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_SalonServicesList()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                salonServices.Setup(repo => repo.SalonServicesList()).ReturnsAsync(_salonServiceList);
                var result = await _salonSpaServices.SalonServicesList();
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test Add Valid Application User is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_User()
        {
            //Arrange
            bool res = false;
            _appointment = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                salonServices.Setup(repo => repo.NewApplicationUser(_user)).ReturnsAsync(res);
                var result = await _salonSpaServices.NewApplicationUser(_user);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test Add Valid Salon Services is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_SalonServices()
        {
            //Arrange
            bool res = false;
            _appointment = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                adminService.Setup(repo => repo.AddSalonServices(_salonServices)).ReturnsAsync(res);
                var result = await _adminServices.AddSalonServices(_salonServices);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test Add Valid Services Plan is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_ServicesPlan()
        {
            //Arrange
            bool res = false;
            _appointment = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                adminService.Setup(repo => repo.AddServicesPlan(_servicesPlan)).ReturnsAsync(res);
                var result = await _adminServices.AddServicesPlan(_servicesPlan);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test GetAppointmentById is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_GetAppointmentById()
        {
            //Arrange
            bool res = false;
            string _appointmentId = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                adminService.Setup(repo => repo.GetAppointmentById(_appointmentId)).ReturnsAsync(_appointment);
                var result = await _adminServices.GetAppointmentById(_appointmentId);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test UpdateAppointment is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_UpdateAppointment()
        {
            //Arrange
            bool res = false;
            string _appointmentId = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                adminService.Setup(repo => repo.UpdateAppointment(_appointmentId)).ReturnsAsync(_appointment);
                var result = await _adminServices.UpdateAppointment(_appointmentId);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test UpdateSalonServices is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_UpdateSalonServices()
        {
            //Arrange
            bool res = false;
            string salonServicesId = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                adminService.Setup(repo => repo.UpdateSalonServices(salonServicesId)).ReturnsAsync(_salonServices);
                var result = await _adminServices.UpdateSalonServices(salonServicesId);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test UpdateServicesPlan is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_UpdateServicesPlan()
        {
            //Arrange
            bool res = false;
            string PlanId = null;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                adminService.Setup(repo => repo.UpdateServicesPlan(PlanId)).ReturnsAsync(_servicesPlan);
                var result = await _adminServices.UpdateServicesPlan(PlanId);
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }

        /// <summary>
        /// This Method is used for test UserAppointment is valid or not
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task<bool> Testfor_Validate_Invlid_UserAppointment()
        {
            //Arrange
            bool res = false;
            string testName; string status;
            testName = CallAPI.GetCurrentMethodName();
            //Act
            try
            {
                //Act
                adminService.Setup(repo => repo.UserAppointment()).ReturnsAsync(_appointmentList);
                var result = await _adminServices.UserAppointments();
                if (result == null)
                {
                    res = true;
                }
            }
            catch (Exception)
            {
                //Assert
                //final result save in text file if exception raised
                status = Convert.ToString(res);
                _output.WriteLine(testName + " Failed");
                await CallAPI.saveTestResult(testName, status, type);
                return false;
            }
            //final result save in text file, Call rest API to save test result
            status = Convert.ToString(res);
            if (res == true)
            {
                _output.WriteLine(testName + " Passed");
            }
            else
            {
                _output.WriteLine(testName + " Failed");
            }

            await CallAPI.saveTestResult(testName, status, type);
            return res;
        }
    }
}
