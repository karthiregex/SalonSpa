﻿using SaloneSpa.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace SaloneSpa.DataLayer
{
    public class SalonSpaDbContext : IdentityDbContext<ApplicationUser>
    {
        public SalonSpaDbContext(DbContextOptions<SalonSpaDbContext> options) : base(options)
        {

        }
        /// <summary>
        /// Seed and create DbSet for all loan class
        /// </summary>
        public DbSet<ApplicationUser> applicationUsers { get; set; }
        public DbSet<Appointment> appointments { get; set; }
        public DbSet<SalonServices> saloneServices { get; set; }
        public DbSet<ServicesPlan> servicePlans { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
        builder.Entity<ApplicationUser>().HasKey(x => x.Id);
            builder.Entity<Appointment>().HasKey(x => x.AppointmentId);
            builder.Entity<SalonServices>().HasKey(x => x.SalonServicesId);
            builder.Entity<ServicesPlan>().HasKey(x => x.ServiceId);
            base.OnModelCreating(builder);
        }
    }
}
