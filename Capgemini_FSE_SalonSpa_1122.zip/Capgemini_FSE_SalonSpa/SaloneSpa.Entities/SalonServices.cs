﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SaloneSpa.Entities
{
    public class SalonServices
    {
        /// <summary>
        /// Use this table for Salon services process 
        /// </summary>
        [Key]
        public string SalonServicesId { get; set; }
        public int ServicesId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Url { get; set; }
        public bool OpenInNewWindow { get; set; }
        public string Description { get; set; }
    }
}