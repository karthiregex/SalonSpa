﻿using SaloneSpa.BusinessLayer.Interfaces;
using SaloneSpa.BusinessLayer.Services.Repository;
using SaloneSpa.Entities;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SaloneSpa.BusinessLayer.Services
{
    public class AdminSalonSpaServices : IAdminSalonSpaServices
    {
        /// <summary>
        /// Creating referance Variable of IAdminSalonSpaServices and injecting in AdminSalonSpaServices constructor
        /// </summary>
        private readonly IAdminSalonSpaRepository _adminSSRepository;
        public AdminSalonSpaServices(IAdminSalonSpaRepository adminSSRepository)
        {
            _adminSSRepository = adminSSRepository;
        }
        /// <summary>
        /// Add new Salon Services to the Database
        /// </summary>
        /// <param name="salonServices"></param>
        /// <returns></returns>
        public async Task<SalonServices> AddSalonServices(SalonServices salonServices)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Add new sevices Plan to the Database
        /// </summary>
        /// <param name="servicesPlan"></param>
        /// <returns></returns>
        public async Task<ServicesPlan> AddServicesPlan(ServicesPlan servicesPlan)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Delete an existing salon services  from Database Collection
        /// </summary>
        /// <param name="SalonServicesId"></param>
        /// <returns></returns>
        public async Task<bool> DeleteSalonServices(string SalonServicesId)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Delete an existing salon services plan  from Database Collection
        /// </summary>
        /// <param name="PlanId"></param>
        /// <returns></returns>
        public async Task<bool> DeleteServicesPlan(string PlanId)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Get a appointment from collection
        /// </summary>
        /// <param name="appointmentId"></param>
        /// <returns></returns>
        public async Task<Appointment> GetAppointmentById(string appointmentId)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Update an existing Appointment that is booked by user
        /// </summary>
        /// <param name="AppointmentId"></param>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<Appointment> UpdateAppointment(string AppointmentId)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Update an existing salon services
        /// </summary>
        /// <param name="SalonServicesId"></param>
        /// <param name="salonServices"></param>
        /// <returns></returns>
        public async Task<SalonServices> UpdateSalonServices(string SalonServicesId)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Update an existing services plan
        /// </summary>
        /// <param name="PlanId"></param>
        /// <param name="servicesPlan"></param>
        /// <returns></returns>
        public Task<ServicesPlan> UpdateServicesPlan(string PlanId)
        {
            //do code here
            throw new NotImplementedException();
        }
        /// <summary>
        /// Book Appointment for salon services.
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<Appointment>> UserAppointments()
        {
            //do code here
            throw new NotImplementedException();
        }
    }
}
