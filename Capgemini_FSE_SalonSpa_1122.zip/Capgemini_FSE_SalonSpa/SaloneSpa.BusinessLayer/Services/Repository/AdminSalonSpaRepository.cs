﻿using SaloneSpa.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using SaloneSpa.DataLayer;

namespace SaloneSpa.BusinessLayer.Services.Repository
{
    public class AdminSalonSpaRepository : IAdminSalonSpaRepository
    {
        /// <summary>
        /// Creating and injecting DbContext in AdminSalonSpaRepository constructor
        /// </summary>
        private readonly SalonSpaDbContext _salonContext;
        public AdminSalonSpaRepository(SalonSpaDbContext salonDbContext)
        {
            _salonContext = salonDbContext;
        }
        /// <summary>
        /// Add new Salon Services to the Database
        /// </summary>
        /// <param name="salonServices"></param>
        /// <returns></returns>
        public async Task<bool> AddSalonServices(SalonServices salonServices)
        {
            try
            {
                await _salonContext.saloneServices.AddAsync(salonServices);
                await _salonContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// Add new sevices Plan to the Database
        /// </summary>
        /// <param name="servicesPlan"></param>
        /// <returns></returns>
        public async Task<bool> AddServicesPlan(ServicesPlan servicesPlan)
        {
            try
            {
                await _salonContext.servicePlans.AddAsync(servicesPlan);
                await _salonContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// Delete an existing salon services  from Database Collection
        /// </summary>
        /// <param name="SalonServicesId"></param>
        /// <returns></returns>
        public async Task<bool> DeleteSalonServices(string SalonServicesId)
        {
            try
            {
                var result = await _salonContext.saloneServices
                  .FirstOrDefaultAsync(h => h.SalonServicesId.Equals(SalonServicesId));
                _salonContext.saloneServices.Remove(result);
                await _salonContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Delete an existing salon services plan  from Database Collection
        /// </summary>
        /// <param name="PlanId"></param>
        /// <returns></returns>
        public async Task<bool> DeleteServicesPlan(string PlanId)
        {
            try
            {
                var result = await _salonContext.servicePlans
                  .FirstOrDefaultAsync(h => h.PlanId.Equals(PlanId));
                _salonContext.servicePlans.Remove(result);
                await _salonContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        /// <summary>
        /// Get a appointment from collection
        /// </summary>
        /// <param name="appointmentId"></param>
        /// <returns></returns>
        public async Task<Appointment> GetAppointmentById(string appointmentId)
        {
            try
            {
                var result = await _salonContext.appointments
                  .FirstOrDefaultAsync(h => h.AppointmentId.Equals(appointmentId));
                return result;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Update an existing Appointment that is booked by user
        /// </summary>
        /// <param name="AppointmentId"></param>
        /// <param name="appointment"></param>
        /// <returns></returns>
        public async Task<Appointment> UpdateAppointment(string AppointmentId)
        {
            try
            {
                var result = await _salonContext.appointments
                 .FirstOrDefaultAsync(h => h.AppointmentId.Equals(AppointmentId));
                _salonContext.appointments.Update(result);
                await _salonContext.SaveChangesAsync();

                var resultUpdated = await _salonContext.appointments
                .FirstOrDefaultAsync(h => h.AppointmentId.Equals(AppointmentId));
                return resultUpdated;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Update an existing salon services
        /// </summary>
        /// <param name="SalonServicesId"></param>
        /// <param name="salonServices"></param>
        /// <returns></returns>
        public async Task<SalonServices> UpdateSalonServices(string SalonServicesId)
        {
            try
            {
                var result = await _salonContext.saloneServices
                 .FirstOrDefaultAsync(h => h.SalonServicesId.Equals(SalonServicesId));
                _salonContext.saloneServices.Update(result);
                await _salonContext.SaveChangesAsync();

                var resultUpdated = await _salonContext.saloneServices
                .FirstOrDefaultAsync(h => h.SalonServicesId.Equals(SalonServicesId));
                return resultUpdated;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// Update an existing services plan
        /// </summary>
        /// <param name="PlanId"></param>
        /// <param name="servicesPlan"></param>
        /// <returns></returns>
        public async Task<ServicesPlan> UpdateServicesPlan(string PlanId)
        {
            try
            {
                var result = await _salonContext.servicePlans
                 .FirstOrDefaultAsync(h => h.PlanId.Equals(PlanId));
                _salonContext.servicePlans.Update(result);
                await _salonContext.SaveChangesAsync();

                var resultUpdated = await _salonContext.servicePlans
                .FirstOrDefaultAsync(h => h.PlanId.Equals(PlanId));
                return resultUpdated;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public async Task<IEnumerable<Appointment>> UserAppointment()
        {
            try
            {
                var result = await _salonContext.appointments.ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
    }
}
