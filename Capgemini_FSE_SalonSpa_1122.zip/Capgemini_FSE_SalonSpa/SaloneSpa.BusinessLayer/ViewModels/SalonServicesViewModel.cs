﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SaloneSpa.BusinessLayer
{
    public class SalonServicesViewModel
    {
        [Required]
        public int ServicesId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Url { get; set; }
        public bool OpenInNewWindow { get; set; }
        public string Description { get; set; }
    }
}
