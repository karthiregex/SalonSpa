﻿using SaloneSpa.Entities;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SaloneSpa.BusinessLayer.Interfaces
{
    public interface IAdminSalonSpaServices
    {
        Task<IEnumerable<Appointment>> UserAppointments();
        Task<Appointment> UpdateAppointment(string AppointmentId);
        Task<Appointment> GetAppointmentById(string appointmentId);
        Task<SalonServices> AddSalonServices(SalonServices salonServices);
        Task<SalonServices> UpdateSalonServices(string SalonServicesId);
        Task<bool> DeleteSalonServices(string SalonServicesId);
        Task<ServicesPlan> AddServicesPlan(ServicesPlan servicesPlan);
        Task<ServicesPlan> UpdateServicesPlan(string PlanId);
        Task<bool> DeleteServicesPlan(string PlanId);
    }
}
